$(document).ready(function () {
    $('#submit').click(function () {

        $.ajax({
            method: 'POST',
            url: 'encrypt.php',
            data: { string: $('#input').val() }
        })
        .done(function (response, status, jqXHR) {
            var formattedResponse = JSON.parse(response);
            $('#output').html('<strong>Clave:</strong> ' + formattedResponse['raw'] + '<br><br>'
            + '<strong>Clave encriptada en md5:</strong> <br>' + formattedResponse['md5'] +  '<br><br>'
            + '<strong>Clave encriptada en sha1:</strong> <br>' + formattedResponse['sha1']);
            $('#state').html('<strong>Status</strong>: ' + status);
        }).fail(function (jqXHR, status, error) {
            $('#state').html('<strong>Status:</strong> ' + status
             + '<br><strong>Error:</strong> ' + error);
        }).always(function () {
            console.log('completed');
        });

    });
});